//import java.util.Collections;
//import java.util.Scanner;
//
//class Node{
//
//    String data;
//    Node next;
//    Node(String d)
//    {
//        data=d;
//        this.next=null;
//    }
//
//
//}
//public class Online_Course_Enrollment_System {
//    Node head;
//    public void addFirst(String v)
//    {
//        Node newNode=new Node(v);
//        if (head==null)
//        {
//            head=newNode;
//            return;
//        }
//        newNode.next=head;
//        head=newNode;
//    }
//    // Add Last
//        public void addLast(String v)
//    {
//        Node newNode=new Node(v);
//        Node current=head;
//        if (head==null)
//        {
//            head=newNode;
//            return;
//        }
//        while (current.next!=null)
//        {
//            current=current.next;
//        }
//        current.next=newNode;
//    }
//
//    // Add Specific Position
//
//    public void addSpecificPosition(int position,String v)
//    {
//        Node newNode=new Node(v);
//        Node currentNode=head;
//        if (position==0)
//        {
//            newNode.next=head;
//            head=newNode;
//            return;
//        }
//
//        if (currentNode==null)
//        {
//            System.out.println("OUT OF BOUNDS");
//            return;
//        }
//
//        for (int i=0;i<position-1 && currentNode!=null;i++)
//        {
//            currentNode=currentNode.next;
//        }
//        newNode.next=currentNode.next;
//        currentNode.next=newNode;
//    }
//
//    public boolean isStudentEnrolled(String d)
//    {
//        Node currentNode=head;
//        while (currentNode!=null)
//        {
//            if (currentNode.data.equalsIgnoreCase(d))
//            {
//                return true;
//            }
//            currentNode=currentNode.next;
//        }
//        return false;
//    }
//    // Print Data
//    public void printData()
//    {
//        Node currentNode=head;
//        while (currentNode!=null)
//        {
//            System.out.print(currentNode.data+"-->");
//            currentNode=currentNode.next;
//        }
//        System.out.print("null");
//    }
//    public static void main(String[] args) {
//        // add First
//        Online_Course_Enrollment_System i=new Online_Course_Enrollment_System();
//        i.addFirst("Arham");
//        i.printData();
//        System.out.println();
//        i.addFirst("Muzaffar");
//        i.printData();
//        System.out.println();
//
//        // add Last
//        System.out.println("Adding The Last ");
//        i.addLast("Ali Hassan");
//        i.printData();
//        System.out.println();
//
//        // specific Position
//        System.out.println("Specific Position");
//        i.addSpecificPosition(1,"Abdullah");
//        i.printData();
//        System.out.println();
//        Scanner input=new Scanner(System.in);
//        System.out.print("Enter The Student Name to check if they are enrolled : ");
//        String data=input.nextLine();
//        if (i.isStudentEnrolled(data))
//        {
//            System.out.println("Student Is Enroll In List");
//        }
//        else {
//            System.out.println("Your Value Can't Find");
//        }
//        System.out.println();
//    }
//}
