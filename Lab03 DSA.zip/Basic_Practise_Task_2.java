//import java.util.LinkedList;
//
//class Node{
//    int data;
//
//    Node next;
//    Node(int d)
//    {
//        this.data=d;
//        this.next=null;
//    }
//
//}
//class LL {
//    Node head;
//
//    public void addLinkedList(int v) {
//        Node newNode = new Node(v);
//        if (head == null) {
//            head = newNode;
//            return;
//        }
//       newNode.next=head;
//        head=newNode;
//    }
//    // Reverse
//    public void reverseLinkedList()
//    {
//        Node currentNode = head,prev=null,next;
//        while (currentNode!=null)
//        {
//            next=currentNode.next;
//            currentNode.next=prev;
//            prev=currentNode;
//            currentNode=next;
//        }
//        head=prev;
//
//    }
//
//    public void printData() {
//        Node currentNode = head;
//        while (currentNode != null) {
//            System.out.print(currentNode.data + "-->");
//            currentNode = currentNode.next;
//        }
//        System.out.print("null");
//
//    }
//}
//    public  class Basic_Practise_Task_2 {
//
//
//        public static void main(String[] args) {
//
//            LL list = new LL();
//            list.addLinkedList(1);
//            list.addLinkedList(2);
//            list.addLinkedList(3);
//            System.out.println("Original Linked List");
//            list.printData();
//
//            list.reverseLinkedList();
//
//            System.out.println("\nReversed list:");
//            list.printData();
//
//
//
//        }
//    }
//
