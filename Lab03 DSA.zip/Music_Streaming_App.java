
import java.util.Collections;
import java.util.Scanner;

class Node{

    String data;
    int duration;
    Node next;
    Node(String d,int duration)
    {
        data=d;
        this.next=null;
        this.duration=duration;
    }


}
public class Music_Streaming_App {
    Node head;
    public void addFirst(String v,int d)
    {
        Node newNode=new Node(v,d);
        if (head==null)
        {
            head=newNode;
            return;
        }
        newNode.next=head;
        head=newNode;
    }
    // Add Last
    public void addLast(String v,int d)
    {
        Node newNode=new Node(v,d);
        Node current=head;
        if (head==null)
        {
            head=newNode;
            return;
        }
        while (current.next!=null)
        {
            current=current.next;
        }
        current.next=newNode;
    }

    // Add Specific Position

    public void addSpecificPosition(int position,String v,int d)
    {
        Node newNode=new Node(v,d);
        Node currentNode=head;
        if (position==0)
        {
            newNode.next=head;
            head=newNode;
            return;
        }

        if (currentNode==null)
        {
            System.out.println("OUT OF BOUNDS");
            return;
        }

        for (int i=0;i<position-1 && currentNode!=null;i++)
        {
            currentNode=currentNode.next;
        }
        newNode.next=currentNode.next;
        currentNode.next=newNode;
    }
    // Check Student Enrolled
    public boolean isSongAvalable(String d)
    {
        Node currentNode=head;
        while (currentNode!=null)
        {
            if (currentNode.data.equalsIgnoreCase(d))
            {
                return true;
            }
            currentNode=currentNode.next;
        }
        return false;
    }

    // Remove Song
    public boolean removeSong(String title) {

        if (head == null) {
            return false;
        }
        if (head.data.equalsIgnoreCase(title)) {
            head = head.next;
            return true;
        }

        Node currentNode = head;
        while (currentNode.next != null) {
            if (currentNode.next.data.equalsIgnoreCase(title)) {
                currentNode.next = currentNode.next.next;
                return true;
            }
            currentNode = currentNode.next;
        }
        return false;
    }
    // Find High Duration
    public String findLongestSong() {
        if (head == null) return null;

        Node current = head;
        Node longest = head;
        while (current != null) {
            if (current.duration > longest.duration) {
                longest = current;
            }
            current = current.next;
        }
        return longest.data;
    }

    // Print Data
    public void displaySong()
    {
        Node currentNode=head;
        while (currentNode!=null)
        {
            System.out.print(currentNode.data+","+currentNode.duration+"-->");
            currentNode=currentNode.next;
        }
        System.out.print("null");
    }
    public static void main(String[] args) {
        // add First
        Music_Streaming_App i=new Music_Streaming_App();
        i.addFirst("Tum Ho",345);
        i.displaySong();
        System.out.println();
        i.addFirst("Hamen Tumse Pyar Kitna",567);
        i.displaySong();
        System.out.println();

        // add Last
        System.out.println("Song Add To Last");
        i.addLast("Yaadon Ki Baaraat",455);
        i.displaySong();
        System.out.println();

        // specific Position
        System.out.println("Specific Position");
        i.addSpecificPosition(1,"In Ankhon Ki Masti",344);
        i.displaySong();
        System.out.println();
        Scanner input=new Scanner(System.in);
        System.out.print("Enter The Song Name to check if they are Available : ");
        String data=input.nextLine();
        if (i.isSongAvalable(data))
        {
            System.out.println("Song Is Available ");
        }
        else {
            System.out.println("Your Song Is Not Available");
        }
        System.out.println();

        System.out.println("Highest Duration Song");
        System.out.println(i.findLongestSong());

    }
}

