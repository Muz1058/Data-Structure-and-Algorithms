//import java.util.LinkedList;
//import java.util.Scanner;
//
//public class Basic_Practise_Task_1 {
//    public static void main(String[] args) {
//
//
//        LinkedList<Integer> linkedList=new LinkedList<>();
//        linkedList.add(1);
//        linkedList.add(2);
//        System.out.println("Before Insertion ");
//        for (int i:linkedList)
//        {
//            System.out.print(i+"-->");
//        }
//        System.out.println("null");
//
//        System.out.println("ADD First");
//        linkedList.addFirst(3);
//        for (int i:linkedList)
//        {
//            System.out.print(i+"-->");
//        }
//        System.out.println("null");
//        System.out.println("Insert At Specific Position");
//        linkedList.add(2,4);
//        for (int i:linkedList)
//        {
//            System.out.print(i+"-->");
//        }
//        System.out.println("null");
//        System.out.println("Add Element To Last");
//        linkedList.addLast(5);
//        for (int i:linkedList)
//        {
//            System.out.print(i+"-->");
//        }
//        System.out.println("null\n");
//
//        System.out.println("Search From The Linked List");
//
//        Scanner  input=new Scanner(System.in);
//        System.out.print("Enter The Value You Can Search In The List : ");
//        int data=input.nextInt();
//        if (linkedList.contains(data))
//        {
//            System.out.println("Value Found In An Linked List");
//        }
//        else {
//            System.out.println("Your Value Can't Find");
//        }
//        System.out.println();
//
//        linkedList.sort(null);
//
//        System.out.println("Traverse Linked List");
//        for (int i:linkedList)
//        {
//            System.out.print(i+"-->");
//        }
//        System.out.println("null");
//
//    }
//}
